import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import Hello, { Hello2, Hello3, Hello4 } from './start.js';
import Hello5 from './Var.js';
import Hello6 from './start2';
import Library from './Library';
import Greeting from './Greeting';
import GreetingAll from './GreetingArray';
import Clock from './Clock';
import Book from './Book_props';
import CommentList from './CommentList';
import User from './ThisStateTest';
import LifeCycleEx from './LifeCycle';
import User2 from './UseStateEx';
import BoardList from './BoardList';

//start.js 파일 내부 Hello 함수 실행 리턴 결과
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {/* <App /> */}
    {/* <Hello />
    <Hello2 />
    <Hello3 />
    <Hello4 />
    <Hello5/> */}
    {/* <Library/> */}
    {/* <GreetingAll/> */}
    {/* <Clock /> */}
    {/* <Book title="책제목1" price="20000" totalPage="200" body="리액트 입문자용입니다." />
    <Book title="책제목2" price="30000" totalPage="300" body="리액트 중급자용입니다."/> */}
    {/* <CommentList/> */}
    {/* <User id="부모에서 전달하는 id"/> */}
    {/* <LifeCycleEx prop_value = "프롭스 전달"/> */}
    {/* <User2 id="부모에서 전달하는 id"/> */}
    <BoardList />
    </React.StrictMode>
);

// const timer = ReactDOM.createRoot(document.getElementById('timer'));
// setInterval(function () {
//   timer.render(
//     <React.StrictMode>
//       <Clock />
//     </React.StrictMode>
//   );
// }, 1000);


// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();