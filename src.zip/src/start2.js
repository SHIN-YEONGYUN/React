import React from 'react';

class Hello6 extends React.Component{
    render(){
    return <div><h1>클래스선언식 리액트</h1></div>;
    }
}

export default Hello6;